export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyCNuUNf9hZlSo3bCP0rn6uOgyfXg_HORcI",
  authDomain: "visitantes-59f4c.firebaseapp.com",
  databaseURL: "https://visitantes-59f4c.firebaseio.com",
  projectId: "visitantes-59f4c",
  storageBucket: "visitantes-59f4c.appspot.com",
  messagingSenderId: "154601440425",
  appId: "1:154601440425:web:e265773446a7a4d93055b8",
  measurementId: "G-KPME7SQK1D"
  }
};
